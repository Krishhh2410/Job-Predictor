# Job-Predictor1
This predict the job percentage in new city.
